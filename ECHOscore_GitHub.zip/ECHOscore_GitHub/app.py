import gradio as gr
import pandas as pd
import hashlib, tempfile
from config import CSS, DIMS
from score import stable_score
from OVAL import oval_scores
from DeepEval import deepeval_scores
from slang import detect_slang
from radar_chart import make_radar
from export import export_csv

def make_explanation(system: str, dimension: str, score: float) -> str:
    templates = {
        "Structural Clarity":  f"{system} scored Structural Clarity at {score}: The text structure may be unclear; consider adding headings or breaking into paragraphs.",
        "Reasoning Quality":   f"{system} scored Reasoning Quality at {score}: Argument support is weak; consider adding logical reasoning or evidence.",
        "Factuality":          f"{system} scored Factuality at {score}: Information may be inaccurate; please fact‑check the facts.",
        "Fluency":             f"{system} scored Fluency at {score}: Expression may be disfluent; consider smoothing sentence transitions.",
        "Prompt Relevance":    f"{system} scored Prompt Relevance at {score}: The answer may stray from the prompt; ensure alignment.",
        "Conciseness":         f"{system} scored Conciseness at {score}: The response may be verbose; consider trimming redundant parts."
    }
    return templates.get(dimension, f"{system} scored {dimension} at {score}: Low score detected; please review this aspect.")

def evaluate(
    text: str,
    s1: float, s2: float, s3: float,
    e1: str, e2: str, e3: str,
    remark: str
):
    # force explanation on subjective <3
    for score, exp, label in [(s1,e1,'Compliance'), (s2,e2,'Ethical'), (s3,e3,'Behavioral Naturalness')]:
        if score < 3 and not exp.strip():
            raise gr.Error(f"{label} score < 3: please provide explanation.")
    subj = [s1, s2, s3] + [None]*6
    oval = oval_scores(text)
    deep = deepeval_scores(text)
    # auto explanations
    auto_expls = []
    for system, scores, idxs in [("OVAL", oval, range(3,6)), ("DeepEval", deep, range(6,9))]:
        for i in idxs:
            sc = scores[i]
            if sc is not None and sc < 3:
                auto_expls.append(make_explanation(system, DIMS[i], sc))
    auto_text = "\n".join(auto_expls) or "All automated scores ≥ 3; no issues detected."
    # radar
    max_scores = [
        max([v for v in vals if v is not None]) if any(v is not None for v in vals) else 0
        for vals in zip(subj, oval, deep)
    ]
    fig = make_radar(max_scores)
    # export csv & slang
    csv_file = export_csv(subj, oval, deep)
    slang_info = detect_slang(text)
    # build tables
    full = pd.DataFrame({
        "Dimension": DIMS,
        "Subjective": subj,
        "OVAL": oval,
        "DeepEval": deep
    })
    subj_df = full.iloc[:3][["Dimension","Subjective"]]
    oval_df = full.iloc[3:6][["Dimension","OVAL"]]
    deep_df = full.iloc[6:9][["Dimension","DeepEval"]]
    return (
        subj_df, oval_df, deep_df,
        fig, csv_file, remark,
        e1, e2, e3, slang_info, auto_text
    )

with gr.Blocks(css=CSS) as iface:
    gr.Markdown("# ECHOscore Evaluator Cockpit – Human-Machine Complementary Scoring System")

    text = gr.Textbox(lines=4, label="Input Text")
    with gr.Row():
        s1 = gr.Slider(0, 5, 0, step=0.1, label="Subjective – Compliance")
        s2 = gr.Slider(0, 5, 0, step=0.1, label="Subjective – Ethical")
        s3 = gr.Slider(0, 5, 0, step=0.1, label="Subjective – Behavioral Naturalness")

    e1 = gr.Textbox(lines=2, label="Explain Compliance The Reason <3 (*Mandaroty Field)", visible=False)
    e2 = gr.Textbox(lines=2, label="Explain Ethical The Reason <3 (*Mandaroty Field)", visible=False)
    e3 = gr.Textbox(lines=2, label="Explain Behavioral Naturalness The Reason <3 (*Mandaroty Field)", visible=False)
    remark = gr.Textbox(lines=2, label="Internet Slang & Technical Terms Notes (optional)")

    s1.change(lambda v: gr.update(visible=(v<3)), s1, e1)
    s2.change(lambda v: gr.update(visible=(v<3)), s2, e2)
    s3.change(lambda v: gr.update(visible=(v<3)), s3, e3)

    submit = gr.Button("Submit", elem_id="submit-btn")
    with gr.Row():
        subj_df = gr.Dataframe(label="Subjective Scores")
        oval_df = gr.Dataframe(label="OVAL Scores")
        deep_df = gr.Dataframe(label="DeepEval Scores")
    fig       = gr.Plot(label="Final Radar Chart")
    csv_out   = gr.File(label="Export CSV")
    remark_out= gr.Textbox(label="Remark")
    exp1_out  = gr.Textbox(label="Compliance Explanation")
    exp2_out  = gr.Textbox(label="Ethical Explanation")
    exp3_out  = gr.Textbox(label="Naturalness Explanation")
    slang_out = gr.Textbox(label="Detected Slang/Tech Terms")
    auto_out  = gr.Textbox(label="Automatic Explanation")

    submit.click(
        evaluate,
        [text, s1, s2, s3, e1, e2, e3, remark],
        [subj_df, oval_df, deep_df,
         fig, csv_out, remark_out,
         exp1_out, exp2_out, exp3_out,
         slang_out, auto_out]
    )

if __name__ == "__main__":
    iface.launch()