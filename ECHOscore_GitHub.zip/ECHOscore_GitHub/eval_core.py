
from config import DIMENSIONS, SYSTEMS
from scoring_utils import stable_score, make_explanation
from radar_chart import make_radar_chart
from export_utils import generate_csv_download
from slang_parser import extract_slang_notes

def evaluate_all(input_text, user_scores, user_notes):
    results = {}
    explanations = {}

    for system in SYSTEMS:
        results[system] = []
        explanations[system] = []
        for dim in DIMENSIONS:
            if system == "Human":
                score = user_scores.get(dim, None)
            else:
                score = stable_score(system, input_text, dim)
            results[system].append(score)
            if score is not None:
                explanations[system].append(make_explanation(system, dim, score))

    radar_fig = make_radar_chart(DIMENSIONS, results)
    cleaned_notes = extract_slang_notes(user_notes)
    csv_path = generate_csv_download(DIMENSIONS, SYSTEMS, results, cleaned_notes)

    return results, explanations, radar_fig, cleaned_notes, csv_path
