
import plotly.graph_objects as go

def make_radar_chart(dimensions, scores_dict):
    fig = go.Figure()

    for system, scores in scores_dict.items():
        fig.add_trace(go.Scatterpolar(
            r=[s if s is not None else 0 for s in scores],
            theta=dimensions,
            fill='toself',
            name=system
        ))

    fig.update_layout(
        polar=dict(
            radialaxis=dict(visible=True, range=[0, 10])
        ),
        showlegend=True,
        autosize=True,
        margin=dict(l=0, r=0, t=20, b=0),
        height=450
    )

    return fig
