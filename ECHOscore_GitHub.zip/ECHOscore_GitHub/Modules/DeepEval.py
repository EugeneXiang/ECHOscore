from score import stable_score
from config import DIMS

def deepeval_scores(text: str) -> list[float | None]:
    """
    Compute DeepEval automated scores for:
      - Fluency
      - Prompt Relevance
      - Conciseness
    """
    vals = [stable_score("DeepEval", text, d) for d in DIMS[6:9]]
    return [None]*6 + vals