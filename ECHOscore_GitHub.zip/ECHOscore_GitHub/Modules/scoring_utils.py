
import hashlib

def stable_score(system, text, dimension):
    h = hashlib.md5(f"{text}_{system}_{dimension}".encode()).hexdigest()
    v = int(h, 16) % 41
    return round(v / 10 + 1, 1)

def make_explanation(system, dimension, score):
    templates = {
        "Structure":         f"{system} scored Structure at {score}: The text structure may be unclear; consider adding headings or breaking into paragraphs.",
        "Rationality":       f"{system} scored Rationality at {score}: Argument support is weak; consider adding logical reasoning or evidence.",
        "Logic":             f"{system} scored Logic at {score}: Flow seems disjointed; check for consistency and coherence between sentences.",
        "Non-hallucination": f"{system} scored Non-hallucination at {score}: There may be inaccurate or made‑up information; please fact‑check.",
        "Accuracy":          f"{system} scored Accuracy at {score}: Minor factual inaccuracies may exist; verify claims against reliable sources.",
        "Coherence":         f"{system} scored Coherence at {score}: Sentences may lack a smooth narrative flow; consider rephrasing.",
        "Compliance":        f"{system} scored Compliance at {score}: Potential issues in legal or content safety compliance detected.",
        "Ethical":           f"{system} scored Ethical at {score}: Some content may raise ethical or cultural concerns.",
        "Naturalness":       f"{system} scored Naturalness at {score}: The tone might sound artificial or robotic; consider improving fluency.",
    }
    return templates.get(dimension, f"{system} scored {dimension} at {score}.")
