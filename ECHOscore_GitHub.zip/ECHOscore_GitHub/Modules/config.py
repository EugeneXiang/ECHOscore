
# 系统名称列表（展示顺序）
SYSTEMS = ["Human", "OVAL", "DeepEval"]

# 维度顺序（统一用于评分、图表、展示）
DIMENSIONS = [
    "Compliance", "Ethical", "Naturalness",
    "Structure", "Rationality", "Logic",
    "Non-hallucination", "Accuracy", "Coherence"
]

# 中文维度映射（可用于表头）
DIMENSION_ZH = {
    "Compliance": "合规性",
    "Ethical": "伦理性",
    "Naturalness": "自然度",
    "Structure": "结构性",
    "Rationality": "合理性",
    "Logic": "逻辑性",
    "Non-hallucination": "非幻觉性",
    "Accuracy": "准确性",
    "Coherence": "连贯性"
}

# 默认打分范围
SCORE_RANGE = (0.0, 10.0)

# 颜色配置（可用于图表）
SYSTEM_COLORS = {
    "Human": "#1f77b4",
    "OVAL": "#2ca02c",
    "DeepEval": "#ff7f0e"
}
