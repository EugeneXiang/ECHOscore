
DIMS = [
    "Compliance",
    "Ethical",
    "Behavioral Naturalness",    # 之前的 Naturalness，更准确地强调行为自然度

    "Structural Clarity",
    "Reasoning Quality",
    "Factuality",                # 之前的 Logic 改为 Factuality

    "Fluency",
    "Prompt Relevance",
    "Conciseness"
]

CSS = """
#submit-btn {
  background-color: orange !important;
  color: white !important;
  border: none !important;
}
#submit-btn:hover {
  background-color: darkorange !important;
}
"""