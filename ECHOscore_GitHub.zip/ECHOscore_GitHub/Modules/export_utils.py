
import csv
import tempfile

def generate_csv_download(dimensions, systems, scores_data, notes, filename="evaluation_scores.csv"):
    output = tempfile.NamedTemporaryFile(delete=False, suffix=".csv", mode="w", newline="", encoding="utf-8")
    writer = csv.writer(output)

    writer.writerow(["维度"] + systems)
    for idx, dim in enumerate(dimensions):
        row = [dim]
        for sys in systems:
            score = scores_data[sys][idx] if scores_data[sys][idx] is not None else ""
            row.append(score)
        writer.writerow(row)

    writer.writerow([])
    writer.writerow(["网络用语备注"])
    writer.writerow([notes])

    output.close()
    return output.name
