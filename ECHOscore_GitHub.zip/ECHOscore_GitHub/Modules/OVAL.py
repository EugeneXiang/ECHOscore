# OVAL.py
from score import stable_score
from config import DIMS

def oval_scores(text: str) -> list[float | None]:
    """
    Compute OVAL automated scores for:
      - Structural Clarity
      - Reasoning Quality
      - Factuality
    """
    vals = [stable_score("OVAL", text, d) for d in DIMS[3:6]]
    return [None]*3 + vals + [None]*3