
import gradio as gr
from config import DIMENSIONS, DIMENSION_ZH
from eval_core import evaluate_all

with gr.Blocks(title="ECHOscore Evaluator Cockpit") as demo:
    gr.Markdown("# 🧠 ECHOscore 评估驾驶舱")

    with gr.Row():
        input_text = gr.Textbox(label="待评估文本", lines=5, placeholder="请输入文本...")

    with gr.Row():
        user_notes = gr.Textbox(label="网络用语备注", lines=2, placeholder="可填写备注，仅用于显示")

    with gr.Accordion("人工评分（选填）", open=False):
        with gr.Row():
            user_inputs = [gr.Slider(minimum=0, maximum=10, step=0.1, label=zh, interactive=True) for zh in DIMENSION_ZH.values()]

    with gr.Row():
        submit_btn = gr.Button("运行评估")

    with gr.Row():
        radar_output = gr.Plot(label="📊 九维雷达图")
    
    with gr.Row():
        notes_out = gr.Textbox(label="🔍 清洗后的网络用语备注", interactive=False)

    with gr.Row():
        csv_file = gr.File(label="📄 下载评分 CSV", interactive=False)

    explanation_boxes = [gr.Textbox(label=f"{sys} 解读", lines=6, interactive=False) for sys in ["Human", "OVAL", "DeepEval"]]

    def run_eval(text, note, *scores):
        user_score_dict = {dim: scores[i] if scores[i] > 0 else None for i, dim in enumerate(DIMENSIONS)}
        results, explanations, fig, clean_notes, csv_path = evaluate_all(text, user_score_dict, note)
        return fig, clean_notes, csv_path, explanations["Human"], explanations["OVAL"], explanations["DeepEval"]

    submit_btn.click(fn=run_eval, 
                     inputs=[input_text, user_notes] + user_inputs, 
                     outputs=[radar_output, notes_out, csv_file] + explanation_boxes)

demo.launch()
